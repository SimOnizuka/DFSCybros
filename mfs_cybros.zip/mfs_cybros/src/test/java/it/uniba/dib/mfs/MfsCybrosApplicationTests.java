package it.uniba.dib.mfs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MfsCybrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
